sizes = input().split()
m = int(sizes[0])
n = int(sizes[1])

array = input()

array = array.replace(' ' ,'' )
print(array)
A , B = input() , input()

A = A.replace(' ' , '')
B = B.replace(' ' , '')
happiness_counter = 0

for i in array:

  if(A.find(i) !=  -1) :
      happiness_counter = happiness_counter+1
  if(B.find(i) != -1):
      happiness_counter = happiness_counter-1 

print(happiness_counter)
