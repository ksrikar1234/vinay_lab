def merge_the_tools(string, k):
    
    for x in range(0,len(string),k):
        temp_list=list(set(string[x:x+k]))
        print(''.join(temp_list))





if __name__ == '__main__':
    string = input()
    k = int(input())
    merge_the_tools(string, k)
