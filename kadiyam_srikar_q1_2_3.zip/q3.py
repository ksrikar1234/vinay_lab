x = input().split()
m = int(x[0])
n = int(x[1])

storage = []


for i in range(0, m):
   storage.append(list(map(int , input().strip().split())))


sum = 0

for i in storage:
    sum = sum + max(i)*max(i)

 
print(sum)
