sizes = input().split()
m = int(sizes[0])
n = int(sizes[1])

array = input().split()

print(array)

A , B = input().split() , input().split()

happiness_counter = 0

for i in array:

  if i in A :
      happiness_counter = happiness_counter+1
  if i in B :
      happiness_counter = happiness_counter-1 

print(happiness_counter)
